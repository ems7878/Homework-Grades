import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;
import java.io.File;
import java.io.PrintWriter;
import java.io.FileNotFoundException;


/*
This program computes the semester grade for each student in a class,
based on exam and homework scores for that student. It reads the data
from a file using File IO. And it passes 3 
arguments into a method and uses them with ArrayLists to do so.
*/

/**
 *
 * @author Esha Shah
 */
public class HW8_Grades {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         Scanner in = new Scanner(System.in);
        
        System.out.printf("Please enter the name of the input file: ");
        String inputName = in.next();
        System.out.printf("Please enter the name of the output CSV file: ");
        String csvName = in.next();
        System.out.printf("Please enter the name of the output pretty-print file: ");
        String prettyName = in.next();

        processGrades(inputName, csvName, prettyName);
        System.out.printf("\n\nExiting...\n");
    }

    public static void processGrades(String input_name, String csv_name,
            String pretty_name) {
        //declaring variables
        PrintWriter outFile;
        PrintWriter outFile2;
        String grade; 
        double smallest;
        //declaring and initializing variables for comparing two numbers for min score
        int chk = 100;
        int chk2 =100;
        
        Scanner inFile = null;
        //using try catch to make sure any exceptions that occur are handled accordingly
        try{
            inFile = new Scanner (new File(input_name)); //read the input file
        }
        catch (FileNotFoundException e){ //if file isn't found, display error message
            System.out.println("File not found: " + input_name);
            return; //end the process if exception found
        }
        
        String titles = inFile.nextLine(); //consume the first line
        
        //take out the names
        //make an ArrayList for each of the columns
        ArrayList<String> fNames = new ArrayList<>();
        ArrayList<String> lNames = new ArrayList<>();
        ArrayList<String> names = new ArrayList<>();
        ArrayList<Integer> exam1 = new ArrayList<>();
        ArrayList<Integer> exam2 = new ArrayList<>();
        ArrayList<Integer> finalExam = new ArrayList<>();
        ArrayList<Integer> hw1 = new ArrayList<>();
        ArrayList<Integer> hw2 = new ArrayList<>();
        ArrayList<Integer> hw3 = new ArrayList<>();
        ArrayList<Integer> hw4 = new ArrayList<>();
        ArrayList<Integer> hw5 = new ArrayList<>();
        ArrayList<Integer> hw6 = new ArrayList<>();
        ArrayList<Integer> hw7 = new ArrayList<>();
       
        
        /*in a loop, take a line from the file
        since each line has information separated with a comma
        split the information 
        and add in the elements in an array
        since each index corresponds to column number
        you can obtain each element at index i
        and put it in the corresponding ArrayList
        */
        
        while (inFile.hasNextLine()){
        String firstNames = inFile.nextLine(); 
        String[] firstNamesArr = firstNames.split(",");
        //because name has first and last name together
        //each element in ArrayList names will have the element in the
        //first column and second column in the input txt file
        names.add(firstNamesArr[0]+ " " +firstNamesArr[1]);
        exam1.add(Integer.parseInt(firstNamesArr[2]));
        exam2.add(Integer.parseInt(firstNamesArr[3]));
        finalExam.add(Integer.parseInt(firstNamesArr[4]));
        hw1.add(Integer.parseInt(firstNamesArr[5]));
        hw2.add(Integer.parseInt(firstNamesArr[6]));
        hw3.add(Integer.parseInt(firstNamesArr[7]));
        hw4.add(Integer.parseInt(firstNamesArr[8]));
        hw5.add(Integer.parseInt(firstNamesArr[9]));
        hw6.add(Integer.parseInt(firstNamesArr[10]));
        hw7.add(Integer.parseInt(firstNamesArr[11]));
        }
       
        //create ArrayLists for holding the calculated numbers
        ArrayList<Double> avg_exam = new ArrayList<>();
        ArrayList<Double> avg_hw = new ArrayList<>();
        ArrayList<String> grades = new ArrayList<>();
        ArrayList<Double> small = new ArrayList<>();
        
        //compute the average from the exams and homeworks
        for( int k =0; k < exam1.size(); k++){
            double avg = (exam1.get(k) + exam2.get(k) + finalExam.get(k)) / 3.0;
            avg_exam.add(avg);
        }
        
        for (int k = 0; k < hw1.size(); k++){
            double avg = (hw1.get(k) + hw2.get(k) + hw3.get(k) + hw4.get(k) + hw5.get(k) + hw6.get(k) + hw7.get(k))/7.0;
            avg_hw.add(avg);
        }
        
    //for every student iteration   
     for(int w = 0; w < exam1.size(); w++) {  
      
         //compare the lowest value between the averages of the exam and homework
         //whichever is the lower one is the minimum score for the student
         for (int k =0; k < avg_exam.size(); k++){
         if(avg_exam.get(k) < avg_hw.get(k)){
             smallest = avg_exam.get(k);
         }
         else{
             smallest = avg_hw.get(k);
         }
                 
        small.add(smallest); //add the minimum score in an ArrayList
        
        //compare the minimum score and compute the grade by comparing against 
        //a scheme
        if(smallest>=90){
            grade = "A";
        }
        else if (smallest>=80){
            grade = "B";
        }
        else if (smallest>=70){
            grade = "C";
        }
        else if (smallest>=60){
            grade = "D";
                   }
        else{
            grade = "F";
        }
        
        grades.add(grade); //add each student's grade in a new ArrayList
    }
     }
        
        
    //print the information in the following output files
    //by passing on the ArrayLists as arguments to outside methods    
    printToFile1(csv_name, names, avg_exam, avg_hw, small, grades);
    printToFile2(pretty_name, names, avg_exam, avg_hw, small, grades);
       
    }
    
    public static void printToFile1 (String fileName, ArrayList<String> names, ArrayList<Double> exam, ArrayList<Double> hw, ArrayList<Double> small, ArrayList<String> grade){
        PrintWriter outFile;
        try {
         outFile = new PrintWriter (fileName);                 
        }
        catch (Exception e){
            System.out.println("File could not be opened: " + fileName);
            return;
        }
        outFile.println("name, exam score, hw score, min score, grade");
        
        //show the information for each student
        for(int i = 0; i < names.size(); i++){
            
           outFile.printf("%s: %.6f, %.6f, %.6f, %s\r\n",
           names.get(i), exam.get(i), hw.get(i), small.get(i), grade.get(i));
        }
        outFile.close();
    }
    
      public static void printToFile2 (String fileName, ArrayList<String> names, ArrayList<Double> exam, ArrayList<Double> hw, ArrayList<Double> small, ArrayList<String> grade){
        PrintWriter outFile;
       
        //try catch for the output file
        try {
         outFile = new PrintWriter (fileName);                 
        }
        catch (Exception e){
            System.out.println("File could not be opened: " + fileName);
            return; //when exception found end the process
        }
        
    //the heading neatly situated in each column        
    outFile.printf("%20s: %10s, %8s, %9s, %s\r\n","name", "exam score", "hw score", "min score", "grade");
     
    //for every student, display the information in a neat format
    for (int i = 0; i < names.size(); i++ ){
        
        outFile.printf("%20s: %10.2f, %8.2f, %9.2f, %s\r\n",
           names.get(i), exam.get(i), hw.get(i), small.get(i), grade.get(i));
        
        }
        outFile.close(); //close the printwriter
    }

    }
    

